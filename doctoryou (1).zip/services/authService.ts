// services/authService.ts

/**
 * Simulates hashing a password. 
 * In a real application, this would use a strong hashing algorithm like bcrypt.
 * @param password - The plaintext password.
 * @returns A simulated hashed password.
 */
export const hashPassword = async (password: string): Promise<string> => {
  // Simulate async operation
  await new Promise(resolve => setTimeout(resolve, 10)); 
  // IMPORTANT: This is NOT secure. It's for demonstration purposes only.
  // A real implementation would be something like:
  // const salt = await bcrypt.genSalt(10);
  // const hash = await bcrypt.hash(password, salt);
  // return hash;
  return `hashed_${password}_${'some_salt'}`;
};

/**
 * Simulates comparing a plaintext password with a hashed one.
 * In a real application, this would use a library function like bcrypt.compare.
 * @param password - The plaintext password to check.
 * @param hashedPassword - The stored hashed password.
 * @returns True if the passwords match, false otherwise.
 */
export const comparePasswords = async (password: string, hashedPassword: string): Promise<boolean> => {
  // Simulate async operation
  await new Promise(resolve => setTimeout(resolve, 10));
  // IMPORTANT: This is NOT secure. It's for demonstration purposes only.
  // A real implementation would be:
  // return await bcrypt.compare(password, hashedPassword);
  return `hashed_${password}_${'some_salt'}` === hashedPassword;
};
