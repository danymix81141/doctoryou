// services/databaseService.ts
import type { User, UserData } from '../types';

const USERS_KEY = 'app_users_v2';
const USERS_DATA_KEY = 'app_users_data_v2';

const simulateDelay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// --- User Management ---

export const getAllUsers = async (): Promise<Record<string, User>> => {
    await simulateDelay(50);
    try {
        const savedUsers = localStorage.getItem(USERS_KEY);
        return savedUsers ? JSON.parse(savedUsers) : {};
    } catch (e) {
        console.error("Failed to parse users from localStorage", e);
        return {};
    }
};

export const saveAllUsers = async (users: Record<string, User>): Promise<void> => {
    await simulateDelay(50);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
};


export const getUser = async (username: string): Promise<User | null> => {
    const users = await getAllUsers();
    return users[username] || null;
};

export const saveUser = async (user: User): Promise<void> => {
    const users = await getAllUsers();
    users[user.username] = user;
    await saveAllUsers(users);
};

// --- UserData Management ---

export const getAllUsersData = async (): Promise<Record<string, UserData>> => {
    await simulateDelay(50);
    try {
        const savedData = localStorage.getItem(USERS_DATA_KEY);
        return savedData ? JSON.parse(savedData) : {};
    } catch (e) {
        console.error("Failed to parse user data from localStorage", e);
        return {};
    }
};

export const getUserData = async (username: string): Promise<UserData | null> => {
    const allData = await getAllUsersData();
    return allData[username] || null;
};

export const saveUserData = async (username:string, data: UserData): Promise<void> => {
    const allData = await getAllUsersData();
    allData[username] = data;
    await simulateDelay(50);
    localStorage.setItem(USERS_DATA_KEY, JSON.stringify(allData));
};