import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import type { PatientAnalysis, DoctorAnalysis, WellnessAnalysis, WellnessInputState, DietDetail } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
const model = 'gemini-2.5-flash';

const patientSchema = {
  type: Type.OBJECT,
  properties: {
    disclaimer: {
      type: Type.STRING,
      description: "Un disclaimer chiaro e prominente che questo non è un sostituto del parere medico professionale."
    },
    possibleConditions: {
      type: Type.ARRAY,
      description: "Una lista di possibili condizioni mediche.",
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: "Il nome della possibile condizione." },
          description: { type: Type.STRING, description: "Una breve descrizione della condizione in termini semplici." },
          treatments: {
            type: Type.ARRAY,
            description: "Suggerimenti di trattamento generali e senza prescrizione.",
            items: { type: Type.STRING }
          },
          whenToSeeDoctor: {
            type: Type.ARRAY,
            description: "Segnali d'allarme chiari o sintomi che indicano quando consultare un medico.",
            items: { type: Type.STRING }
          },
        },
        required: ["name", "description", "treatments", "whenToSeeDoctor"]
      }
    }
  },
  required: ["disclaimer", "possibleConditions"]
};

const doctorSchema = {
  type: Type.OBJECT,
  properties: {
    disclaimer: {
      type: Type.STRING,
      description: "Un disclaimer per il professionista medico che questo è uno strumento di supporto decisionale e non sostituisce il giudizio clinico."
    },
    differentialDiagnosis: {
      type: Type.ARRAY,
      description: "Una diagnosi differenziale dettagliata per un professionista medico.",
      items: {
        type: Type.OBJECT,
        properties: {
          condition: { type: Type.STRING, description: "Il nome della condizione medica." },
          icd10Code: { type: Type.STRING, description: "Il codice ICD-10 associato." },
          medications: {
            type: Type.ARRAY,
            description: "Classi di farmaci specifici con obbligo di ricetta o trattamenti da considerare.",
            items: { type: Type.STRING }
          },
          clinicalInsights: {
            type: Type.STRING,
            description: "Dettagli clinici chiave per la differenziazione e ulteriori passaggi diagnostici."
          }
        },
        required: ["condition", "icd10Code", "medications", "clinicalInsights"]
      }
    },
    suggestedReferral: {
        type: Type.STRING,
        description: "Una bozza di richiesta medica/prescrizione per una visita specialistica, esami diagnostici o trattamenti, basata sull'analisi."
    }
  },
  required: ["disclaimer", "differentialDiagnosis", "suggestedReferral"]
};

const wellnessSchema = {
    type: Type.OBJECT,
    properties: {
        disclaimer: {
            type: Type.STRING,
            description: "Un disclaimer chiaro che consiglia di consultare un medico o un professionista prima di iniziare qualsiasi dieta o programma di fitness."
        },
        dietaConsigliata: {
            type: Type.OBJECT,
            description: "La raccomandazione della dieta più adatta, con una motivazione.",
            properties: {
                nome: { type: Type.STRING, description: "Il nome della dieta che l'IA ha scelto o confermato." },
                motivazione: { type: Type.STRING, description: "La spiegazione del perché questa dieta è la scelta migliore per l'utente, basata sui suoi dati." }
            },
            required: ["nome", "motivazione"]
        },
        fabbisognoCaloricoGiornaliero: {
            type: Type.OBJECT,
            description: "Stima del fabbisogno calorico giornaliero.",
            properties: {
                valore: { type: Type.NUMBER, description: "Il valore numerico delle calorie stimate (es. 2000)." },
                spiegazione: { type: Type.STRING, description: "Una breve spiegazione su come è stato calcolato il valore (es. basato su BMR e livello di attività)." }
            },
            required: ["valore", "spiegazione"]
        },
        pianoAlimentare: {
            type: Type.ARRAY,
            description: "Un piano alimentare dettagliato basato sulla dieta consigliata. Per 1 giorno se l'utente è free, per 14 giorni se è pro.",
            items: {
                type: Type.OBJECT,
                properties: {
                    giorno: { type: Type.NUMBER, description: "Il numero del giorno del piano (es. 1 per free, 1-14 per pro)." },
                    pasti: {
                        type: Type.ARRAY,
                        description: "I pasti per questo giorno, inclusi colazione, pranzo, cena e spuntini.",
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                pasto: { type: Type.STRING, description: "Il tipo di pasto (es. Colazione, Pranzo, Cena, Spuntino)." },
                                descrizione: { type: Type.STRING, description: "Una descrizione dettagliata del pasto suggerito." },
                                calorieStimate: { type: Type.NUMBER, description: "Le calorie stimate per questo specifico pasto."}
                            },
                            required: ["pasto", "descrizione", "calorieStimate"]
                        }
                    }
                },
                required: ["giorno", "pasti"]
            }
        },
        suggerimentiAttivitaFisica: {
            type: Type.ARRAY,
            description: "Suggerimenti per un piano di attività fisica settimanale.",
            items: {
                type: Type.OBJECT,
                properties: {
                    tipo: { type: Type.STRING, description: "Il tipo di attività (es. Cardio, Forza, Flessibilità)." },
                    descrizione: { type: Type.STRING, description: "Una descrizione dell'attività o degli esercizi." },
                    frequenza: { type: Type.STRING, description: "La frequenza settimanale suggerita (es. '3-4 volte a settimana')." }
                },
                required: ["tipo", "descrizione", "frequenza"]
            }
        },
        suggerimentiIntegratori: {
            type: Type.ARRAY,
            description: "Suggerimenti per integratori non obbligatori, personalizzati per l'obiettivo dell'utente.",
            items: {
                type: Type.OBJECT,
                properties: {
                    nome: { type: Type.STRING, description: "Nome dell'integratore (es. Proteine Whey, Creatina Monoidrato)." },
                    scopo: { type: Type.STRING, description: "Lo scopo principale dell'integratore in relazione all'obiettivo." },
                    dosaggioConsigliato: { type: Type.STRING, description: "Dosaggio e modalità d'uso suggeriti (es. '30g dopo l'allenamento')." }
                },
                required: ["nome", "scopo", "dosaggioConsigliato"]
            }
        },
        listaSpesa: {
            type: Type.ARRAY,
            description: "Una lista della spesa aggregata. Deve essere un array vuoto se l'utente è 'free'.",
            items: {
                type: Type.OBJECT,
                properties: {
                    ingrediente: { type: Type.STRING, description: "Il nome dell'ingrediente." },
                    quantita: { type: Type.STRING, description: "La quantità totale necessaria (es. '500g', '2 litri', '1 confezione')." }
                },
                required: ["ingrediente", "quantita"]
            }
        },
        costoApprossimativo: {
            type: Type.OBJECT,
            description: "Una stima del costo totale approssimativo. Deve essere un oggetto vuoto o con valori nulli se l'utente è 'free'.",
            properties: {
                valore: { type: Type.NUMBER, description: "Il valore numerico del costo stimato (es. 150.50)." },
                valuta: { type: Type.STRING, description: "La valuta del costo (es. 'EUR')." },
                spiegazione: { type: Type.STRING, description: "Una breve spiegazione su come è stato stimato il costo (es. basato sui prezzi medi dei supermercati italiani)." }
            },
            required: ["valore", "valuta", "spiegazione"]
        }
    },
    required: ["disclaimer", "dietaConsigliata", "fabbisognoCaloricoGiornaliero", "pianoAlimentare", "suggerimentiAttivitaFisica", "suggerimentiIntegratori", "listaSpesa", "costoApprossimativo"]
};

const dietDetailSchema = {
    type: Type.OBJECT,
    properties: {
        nome: { type: Type.STRING, description: "Il nome della dieta." },
        descrizione: { type: Type.STRING, description: "Una breve descrizione della dieta." },
        principiChiave: { type: Type.ARRAY, items: { type: Type.STRING }, description: "I principi fondamentali della dieta." },
        potenzialiBenefici: { type: Type.ARRAY, items: { type: Type.STRING }, description: "I potenziali benefici per la salute." },
        rischiEConsiderazioni: { type: Type.ARRAY, items: { type: Type.STRING }, description: "I rischi o le cose da considerare prima di iniziare." },
        alimentiConsigliati: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Una lista di alimenti da mangiare." },
        alimentiDaEvitare: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Una lista di alimenti da evitare." },
        esempioPianoGiornaliero: {
            type: Type.ARRAY,
            description: "Un esempio di piano alimentare per una giornata tipo.",
            items: {
                type: Type.OBJECT,
                properties: {
                    pasto: { type: Type.STRING, description: "Tipo di pasto (es. Colazione, Pranzo, Cena, Spuntino)." },
                    descrizione: { type: Type.STRING, description: "Esempio di cosa mangiare per quel pasto." }
                },
                required: ["pasto", "descrizione"]
            }
        }
    },
    required: ["nome", "descrizione", "principiChiave", "potenzialiBenefici", "rischiEConsiderazioni", "alimentiConsigliati", "alimentiDaEvitare", "esempioPianoGiornaliero"]
};


export const getPatientAnalysis = async (symptomsPrompt: string): Promise<PatientAnalysis> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: model,
      contents: `Basandoti sui seguenti dati dell'utente, fornisci: 1. Una lista di possibili condizioni. 2. Suggerimenti di trattamento generali e senza prescrizione per ciascuna. 3. Segnali d'allarme chiari o sintomi che indicano quando consultare immediatamente un medico. Dati utente: \n${symptomsPrompt}`,
      config: {
        systemInstruction: "Sei un assistente medico IA. Il tuo scopo è fornire informazioni preliminari basate sui sintomi riportati dall'utente. NON DEVI fornire una diagnosi definitiva. Inizia sempre la tua risposta con un disclaimer chiaro ed evidente che questo non è un sostituto del parere medico professionale e che l'utente dovrebbe consultare un medico per qualsiasi problema di salute. Il tuo linguaggio deve essere semplice e di facile comprensione per una persona non esperta. Rispondi in italiano.",
        responseMimeType: "application/json",
        responseSchema: patientSchema,
      }
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as PatientAnalysis;
  } catch (error) {
    console.error("Error getting patient analysis:", error);
    throw new Error("Impossibile analizzare i sintomi. Assicurati che la tua API key sia valida e riprova.");
  }
};

export const getDoctorAnalysis = async (doctorPrompt: string): Promise<DoctorAnalysis> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: model,
      contents: `Per un paziente che presenta i seguenti dati: \n${doctorPrompt}\n, fornisci una diagnosi differenziale che includa: 1. Possibili condizioni. 2. Codici ICD-10. 3. Farmaci/Trattamenti. 4. Approfondimenti clinici. INOLTRE, genera una bozza di richiesta medica concisa per le cure/visite/esami più pertinenti basata sulla tua analisi.`,
      config: {
        systemInstruction: "Sei un'intelligenza artificiale esperta nel supporto alle decisioni cliniche, destinata a professionisti del settore medico. Inizia sempre la tua risposta con un disclaimer che lo strumento è inteso come supporto decisionale e non sostituisce il giudizio clinico del professionista. Fornisci informazioni tecniche dettagliate e una bozza di richiesta medica basata sui dati forniti. Il tuo output deve essere strutturato per l'uso da parte di un clinico. Rispondi in italiano.",
        responseMimeType: "application/json",
        responseSchema: doctorSchema,
      }
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as DoctorAnalysis;
  } catch (error) {
    console.error("Error getting doctor analysis:", error);
    throw new Error("Impossibile generare l'analisi clinica. Assicurati che la tua API key sia valida e riprova.");
  }
};

const obiettivoLabels: { [key: string]: string } = {
    'dimagrire': 'Dimagrire',
    'ingrassare': 'Aumentare di peso',
    'aumentare_massa_muscolare': 'Aumentare massa muscolare',
    'migliorare_salute': 'Migliorare la salute generale',
    'gestire_patologie': 'Gestire intolleranze o patologie'
};

export const getWellnessAnalysis = async (input: WellnessInputState, tier: 'free' | 'pro'): Promise<WellnessAnalysis> => {
    const condizioniSelezionate = input.condizioniMediche.length > 0 ? input.condizioniMediche.join(', ') : 'Nessuna condizione medica specifica fornita.';
    const allergieTesto = input.allergieEPreferenze.trim() || 'Nessuna allergia o preferenza specifica fornita.';
    const condizioniCompleto = `Condizioni Mediche Dichiarate: ${condizioniSelezionate}. Allergie o Preferenze: ${allergieTesto}.`;
    const obiettivoUtente = obiettivoLabels[input.obiettivo] || 'Non specificato';
    const stileAlimentareUtente = input.stileAlimentare || 'non specificato';
    const dietaSceltaUtente = input.dietaScelta || "Nessuna, l'utente chiede all'IA di scegliere.";


    const prompt = `
      Analizza i dati dell'utente e genera un piano benessere personalizzato in formato JSON.

      **Dati Utente:**
      - Età: ${input.eta || 'non specificata'}
      - Sesso: ${input.sesso || 'non specificato'}
      - Altezza: ${input.altezza || 'non specificata'} cm
      - Peso: ${input.peso || 'non specificato'} kg
      - Livello di attività: ${input.livelloAttivita || 'non specificato'}
      - Obiettivo Principale: ${obiettivoUtente}
      - Stile Alimentare: ${stileAlimentareUtente}
      - Dieta Scelta dall'Utente: ${dietaSceltaUtente}
      - Condizioni Mediche, Allergie e Preferenze: ${condizioniCompleto}
      - Piano Utente: ${tier === 'pro' ? 'PRO (Completo)' : 'GRATUITO (Anteprima)'}

      **Istruzioni per il JSON da generare:**
      
      - **Piano Basato sul Tier**: Se il Piano Utente è 'GRATUITO (Anteprima)', il campo 'pianoAlimentare' deve contenere un piano per **1 solo giorno**. I campi 'listaSpesa' e 'costoApprossimativo' devono essere un array vuoto e un oggetto con valori a 0 o stringhe vuote, rispettivamente. Se il Piano Utente è 'PRO (Completo)', il 'pianoAlimentare' deve essere di **14 giorni** e tutti i campi, inclusi 'listaSpesa' e 'costoApprossimativo', devono essere popolati.
      - **dietaConsigliata**: Questo è il campo più importante. Valuta la dieta scelta dall'utente. Se è adatta al suo obiettivo e condizioni, conferma la scelta nella 'motivazione'. Se la scelta non è adatta, o se l'utente non ha scelto nulla, raccomanda tu la dieta più appropriata (es. Mediterranea, DASH) e spiega il perché nella 'motivazione'. Il campo 'nome' deve contenere la dieta FINALE su cui si baserà l'intero piano.
      - **coerenza**: Tutti gli altri campi del piano (pianoAlimentare, listaSpesa, suggerimentiAttivitaFisica, etc.) devono essere generati STRETTAMENTE in base ai principi della dieta finale indicata nel campo 'nome' di 'dietaConsigliata'.
      - **sicurezza**: Il piano deve essere assolutamente sicuro e adatto alle condizioni mediche dichiarate dall'utente (es. dieta a basso contenuto di sodio per l'ipertensione, esercizi a basso impatto per l'artrite).
      - **completezza**: Popola tutti i campi dello schema come richiesto dalle istruzioni sul tier.
    `;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                systemInstruction: "Sei un consulente del benessere e della nutrizione IA. Il tuo scopo è fornire suggerimenti generali per una dieta equilibrata e un piano di attività fisica basati sui dati forniti. NON fornire consigli medici specifici o diagnosi. Inizia sempre la tua risposta JSON con un disclaimer che sottolinea l'importanza di consultare un medico, un dietologo e un personal trainer professionista prima di iniziare qualsiasi nuovo regime, specialmente in presenza di condizioni mediche preesistenti. Rispondi in italiano.",
                responseMimeType: "application/json",
                responseSchema: wellnessSchema,
            }
        });
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as WellnessAnalysis;
    } catch (error) {
        console.error("Error getting wellness analysis:", error);
        throw new Error("Impossibile generare il piano benessere. Assicurati che la tua API key sia valida e riprova.");
    }
};

export const getDietDetails = async (dietName: string): Promise<DietDetail> => {
    const prompt = `Fornisci una descrizione dettagliata per la "${dietName}". La risposta deve essere in formato JSON e seguire lo schema fornito. Sii completo, accurato e usa un linguaggio chiaro. Rispondi in italiano.`;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                systemInstruction: "Sei un'enciclopedia della nutrizione e delle diete. Fornisci informazioni oggettive e bilanciate sui diversi regimi alimentari. Evita opinioni personali e concentrati sui dati scientifici e sulle linee guida generali. Includi sempre una sezione sui rischi e le considerazioni.",
                responseMimeType: "application/json",
                responseSchema: dietDetailSchema,
            }
        });
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as DietDetail;
    } catch (error) {
        console.error(`Error getting details for ${dietName}:`, error);
        throw new Error(`Impossibile recuperare i dettagli per la ${dietName}. Riprova più tardi.`);
    }
};