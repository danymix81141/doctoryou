
import React from 'react';
import type { PatientAnalysis } from '../types';
import { PillIcon, AlertTriangleIcon } from './icons';

interface PatientResultsProps {
  data: PatientAnalysis;
}

const PatientResults: React.FC<PatientResultsProps> = ({ data }) => {
  return (
    <div className="space-y-8">
      <div className="bg-amber-50 border-l-4 border-amber-400 text-amber-900 p-4 rounded-r-lg" role="alert">
        <div className="flex">
          <div className="py-1"><AlertTriangleIcon className="h-6 w-6 text-amber-500 mr-4"/></div>
          <div>
            <p className="font-bold">Disclaimer Medico</p>
            <p className="text-sm">{data.disclaimer}</p>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <h2 className="text-3xl font-bold text-gray-800 border-b-2 border-gray-200 pb-3">Possibili Condizioni</h2>
        {data.possibleConditions.map((condition, index) => (
          <div key={index} className="bg-white p-6 rounded-xl shadow-lg border border-gray-200/80 transition-shadow hover:shadow-xl">
            <h3 className="text-2xl font-semibold text-indigo-700 mb-3">{condition.name}</h3>
            <p className="text-gray-600 mb-6">{condition.description}</p>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="flex items-center text-lg font-semibold text-gray-700 mb-2">
                  <PillIcon className="h-5 w-5 mr-3 text-green-600" />
                  Trattamenti Suggeriti
                </h4>
                <ul className="list-disc list-inside space-y-2 text-gray-600 pl-2">
                  {condition.treatments.map((treatment, i) => <li key={i}>{treatment}</li>)}
                </ul>
              </div>
              
              <div className="border-t md:border-t-0 md:border-l border-gray-200 pl-0 md:pl-6 pt-6 md:pt-0">
                <h4 className="flex items-center text-lg font-semibold text-gray-700 mb-2">
                  <AlertTriangleIcon className="h-5 w-5 mr-3 text-red-600" />
                  Quando Contattare un Medico
                </h4>
                <ul className="list-disc list-inside space-y-2 text-gray-600 pl-2">
                  {condition.whenToSeeDoctor.map((warning, i) => <li key={i}>{warning}</li>)}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PatientResults;