import React from 'react';
import { SettingsIcon, LogOutIcon } from './icons';
import type { User } from '../types';

interface AdminPanelProps {
    onLogout: () => void;
    users: Record<string, User>;
    onUpdateUserTier: (username: string) => void;
}

const Switcher: React.FC<{ label: string, id: string }> = ({ label, id }) => (
    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200">
        <label htmlFor={id} className="font-medium text-gray-700 select-none cursor-pointer">
            {label}
        </label>
        <div className="relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in">
            <input type="checkbox" name={id} id={id} className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer"/>
            <label htmlFor={id} className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer"></label>
        </div>
        <style>{`
            .toggle-checkbox:checked { right: 0; border-color: #4f46e5; }
            .toggle-checkbox:checked + .toggle-label { background-color: #4f46e5; }
        `}</style>
    </div>
);

const AdminPanel: React.FC<AdminPanelProps> = ({ onLogout, users, onUpdateUserTier }) => {
    const regularUsers = Object.values(users).filter(u => u.username !== 'admin');

    return (
        <div className="bg-white p-6 sm:p-8 rounded-xl shadow-lg border border-gray-200/80">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center border-b border-gray-200 pb-4 mb-6 gap-4">
                <h2 className="text-2xl font-bold text-gray-800 flex items-center">
                    <SettingsIcon className="h-7 w-7 mr-3 text-gray-600 flex-shrink-0"/>
                    Pannello di Amministrazione
                </h2>
                <button 
                  onClick={onLogout}
                  className="inline-flex items-center justify-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
                >
                    <LogOutIcon className="h-5 w-5 mr-2" />
                    Logout
                </button>
            </div>
            
            <div className="space-y-8">
                <div>
                    <h3 className="text-xl font-bold text-gray-800 mb-4">Impostazioni App</h3>
                    <div className="space-y-4">
                        <Switcher label="Modalità Manutenzione" id="maintenance-mode"/>
                        <Switcher label="Abilita Logging Avanzato" id="advanced-logging"/>
                        <Switcher label="Svuota Cache API" id="clear-cache"/>
                    </div>
                </div>

                <div>
                    <h3 className="text-xl font-bold text-gray-800 mb-4">Gestione Utenti</h3>
                    <div className="overflow-x-auto border border-gray-200 rounded-lg">
                        <table className="w-full text-left table-auto">
                            <thead className="bg-gray-50 text-gray-500 uppercase text-sm">
                                <tr>
                                    <th className="p-4 font-semibold">Username</th>
                                    <th className="p-4 font-semibold">Piano</th>
                                    <th className="p-4 font-semibold text-right">Azione</th>
                                </tr>
                            </thead>
                            <tbody className="text-gray-700">
                                {regularUsers.length > 0 ? regularUsers.map(user => (
                                    <tr key={user.username} className="border-t border-gray-200 hover:bg-gray-50/70">
                                        <td className="p-4 font-medium">{user.username}</td>
                                        <td className="p-4">
                                            <span className={`text-xs font-bold uppercase px-2 py-1 rounded-full ${user.tier === 'pro' ? 'bg-amber-100 text-amber-800' : 'bg-gray-200 text-gray-700'}`}>
                                                {user.tier}
                                            </span>
                                        </td>
                                        <td className="p-4 text-right">
                                            {user.tier === 'free' && (
                                                <button 
                                                    onClick={() => onUpdateUserTier(user.username)}
                                                    className="px-3 py-1 bg-green-600 text-white text-xs font-semibold rounded-md shadow-sm hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-colors"
                                                >
                                                    Upgrade a PRO
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                )) : (
                                    <tr>
                                        <td colSpan={3} className="text-center p-8 text-gray-500">Nessun utente registrato.</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AdminPanel;