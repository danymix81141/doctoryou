import React, { useState, useCallback } from 'react';
import { getDietDetails } from '../services/geminiService';
import type { DietDetail as DietDetailType } from '../types';
import LoadingSpinner from './LoadingSpinner';
import DietDetail from './DietDetail';
import { BookOpenIcon } from './icons';

interface DietLibraryProps {
    onExit: () => void;
}

const dietList = [
    "Dieta Mediterranea",
    "Dieta Chetogenica",
    "Dieta Vegana",
    "Dieta Vegetariana",
    "Dieta Paleo",
    "Dieta DASH",
    "Dieta a Basso Contenuto di FODMAP",
    "Digiuno Intermittente",
    "Dieta Dukan"
];

const DietLibrary: React.FC<DietLibraryProps> = ({ onExit }) => {
    const [selectedDiet, setSelectedDiet] = useState<string | null>(null);
    const [dietDetails, setDietDetails] = useState<DietDetailType | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSelectDiet = useCallback(async (dietName: string) => {
        setSelectedDiet(dietName);
        setIsLoading(true);
        setError(null);
        setDietDetails(null);
        try {
            const details = await getDietDetails(dietName);
            setDietDetails(details);
        } catch (err: any) {
            setError(err.message || 'Si è verificato un errore sconosciuto.');
        } finally {
            setIsLoading(false);
        }
    }, []);

    const handleBackToList = () => {
        setSelectedDiet(null);
        setDietDetails(null);
        setError(null);
    };

    if (dietDetails) {
        return <DietDetail diet={dietDetails} onBack={handleBackToList} />;
    }

    return (
        <div className="bg-white p-6 sm:p-8 rounded-xl shadow-lg border border-gray-200/80 space-y-6">
            <div className="flex justify-between items-start flex-wrap gap-4 border-b border-gray-200 pb-4">
                <div className="flex items-center gap-4">
                    <BookOpenIcon className="h-10 w-10 text-teal-500 flex-shrink-0" />
                    <div>
                         <h2 className="text-3xl font-bold text-gray-800">Libreria delle Diete</h2>
                         <p className="mt-1 text-lg text-gray-600">Seleziona un regime per esplorarne i dettagli.</p>
                    </div>
                </div>
                <button
                  onClick={onExit}
                  className="px-4 py-2 bg-gray-200 text-gray-700 font-semibold rounded-lg hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
                >
                  &larr; Torna al menu
                </button>
            </div>

            {isLoading ? (
                <LoadingSpinner />
            ) : error ? (
                 <div className="bg-red-100 border-l-4 border-red-500 text-red-800 p-4 rounded-md" role="alert">
                    <p className="font-bold">Errore</p>
                    <p>{error}</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    {dietList.map(diet => (
                        <button
                            key={diet}
                            onClick={() => handleSelectDiet(diet)}
                            className="p-4 text-center font-semibold text-indigo-700 bg-indigo-50/70 rounded-lg shadow-sm border border-gray-200 hover:bg-indigo-100 hover:shadow-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                        >
                            {diet}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
};

export default DietLibrary;