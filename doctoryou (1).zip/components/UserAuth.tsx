import React, { useState } from 'react';
import { AlertTriangleIcon } from './icons';

interface UserAuthProps {
  onLogin: (username: string, pass: string) => Promise<boolean>;
  onRegister: (username: string, pass: string) => Promise<boolean>;
  error: string | null;
  setError: (error: string | null) => void;
}

const UserAuth: React.FC<UserAuthProps> = ({ onLogin, onRegister, error, setError }) => {
  const [isLoginView, setIsLoginView] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setError("Nome utente e password non possono essere vuoti.");
      return;
    }
    setError(null);
    setIsSubmitting(true);

    let success = false;
    if (isLoginView) {
      success = await onLogin(username, password);
    } else {
      success = await onRegister(username, password);
    }
    
    setIsSubmitting(false);

    if (success) {
      setUsername('');
      setPassword('');
    }
  };

  const toggleView = () => {
    setIsLoginView(!isLoginView);
    setError(null);
    setUsername('');
    setPassword('');
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="bg-white p-6 sm:p-8 rounded-xl shadow-lg border border-gray-200/80">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
          {isLoginView ? 'Accedi al Tuo Account' : 'Crea un Nuovo Account'}
        </h2>
        
        <div className="bg-blue-50 border-l-4 border-blue-400 text-blue-900 p-4 rounded-r-lg mb-6" role="alert">
          <div className="flex">
            <div className="py-1"><AlertTriangleIcon className="h-6 w-6 text-blue-500 mr-4 flex-shrink-0"/></div>
            <div>
              <p className="font-bold">Sistema Dimostrativo</p>
              <p className="text-sm">Questo sistema è a scopo dimostrativo. Non usare password reali. Le password sono gestite in modo sicuro (hashing simulato).</p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="auth-username" className="block text-md font-medium text-gray-700 mb-1">
              Nome Utente
            </label>
            <input 
              type="text"
              id="auth-username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full p-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
              placeholder="es: mario.rossi"
              required
              autoComplete="username"
              disabled={isSubmitting}
            />
          </div>
          <div>
            <label htmlFor="auth-password"  className="block text-md font-medium text-gray-700 mb-1">
              Password
            </label>
            <input 
              type="password"
              id="auth-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
              placeholder="••••••••"
              required
              autoComplete={isLoginView ? "current-password" : "new-password"}
              disabled={isSubmitting}
             />
          </div>

          {error && <p className="text-red-600 text-sm font-medium">{error}</p>}

          <div className="pt-2">
            <button 
              type="submit" 
              className="w-full px-8 py-3 border border-transparent text-md font-semibold rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors disabled:bg-gray-400 disabled:cursor-wait"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Verifica in corso...' : (isLoginView ? 'Accedi' : 'Registrati')}
            </button>
          </div>
        </form>

        <p className="text-center text-sm text-gray-600 mt-6">
          {isLoginView ? 'Non hai un account?' : 'Hai già un account?'}
          <button onClick={toggleView} className="font-semibold text-indigo-600 hover:text-indigo-500 ml-2" disabled={isSubmitting}>
            {isLoginView ? 'Registrati ora' : 'Accedi'}
          </button>
        </p>
      </div>
    </div>
  );
};

export default UserAuth;