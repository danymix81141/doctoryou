import React from 'react';
import type { DoctorInputState } from '../types';

interface DoctorInputFormProps {
  input: DoctorInputState;
  setInput: (input: DoctorInputState) => void;
}

const sintomiComuni = [
    "Febbre", "Tosse", "Mal di gola", "Congestione nasale", "Naso che cola",
    "Mal di testa", "Dolori muscolari/articolari", "Stanchezza/Affaticamento",
    "Nausea/Vomito", "Diarrea", "Dolore addominale", "Eruzione cutanea", "Fiato corto"
];


const DoctorInputForm: React.FC<DoctorInputFormProps> = ({ input, setInput }) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setInput({ ...input, [e.target.name]: e.target.value });
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value, checked } = e.target;
    setInput({
      ...input,
      sintomiSelezionati: checked
        ? [...input.sintomiSelezionati, value]
        : input.sintomiSelezionati.filter((s) => s !== value),
    });
  };

  return (
    <div className="space-y-6">
        <div className="space-y-4 rounded-lg border border-gray-200 p-4 bg-gray-50">
            <label className="block text-md font-medium text-gray-700 mb-3">
              Sintomi Principali
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {sintomiComuni.map((sintomo) => (
                    <label key={sintomo} className="flex items-center p-3 rounded-lg hover:bg-indigo-50 transition-colors cursor-pointer border border-gray-200">
                        <input
                            type="checkbox"
                            value={sintomo}
                            checked={input.sintomiSelezionati.includes(sintomo)}
                            onChange={handleCheckboxChange}
                            className="h-5 w-5 rounded border-gray-400 text-indigo-600 focus:ring-indigo-500 mr-3"
                        />
                        <span className="text-gray-700 select-none">{sintomo}</span>
                    </label>
                ))}
            </div>
            <div className="mt-4">
                <label htmlFor="altriSintomi" className="block text-md font-medium text-gray-700 mb-1">
                  Altri sintomi o dettagli (es. tipo di tosse, localizzazione del dolore)
                </label>
                <textarea
                  name="altriSintomi"
                  id="altriSintomi"
                  value={input.altriSintomi}
                  onChange={handleChange}
                  placeholder="Descrivere eventuali altri sintomi non in elenco o fornire maggiori dettagli..."
                  className="w-full h-24 p-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
                  rows={3}
                ></textarea>
            </div>
        </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="eta" className="block text-md font-medium text-gray-700 mb-1">
            Età Paziente
          </label>
          <input
            type="number"
            name="eta"
            id="eta"
            value={input.eta}
            onChange={handleChange}
            placeholder="Es: 55"
            className="w-full p-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
          />
        </div>
        <div>
          <label htmlFor="sesso" className="block text-md font-medium text-gray-700 mb-1">
            Sesso Biologico
          </label>
          <select
            name="sesso"
            id="sesso"
            value={input.sesso}
            onChange={handleChange}
            className="w-full p-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
          >
            <option value="">Non specificato</option>
            <option value="Maschio">Maschio</option>
            <option value="Femmina">Femmina</option>
          </select>
        </div>
      </div>

      <div>
        <label htmlFor="storiaClinica" className="block text-md font-medium text-gray-700 mb-1">
          Storia Clinica e Anamnesi
        </label>
        <textarea
          name="storiaClinica"
          id="storiaClinica"
          value={input.storiaClinica}
          onChange={handleChange}
          placeholder="Descrivere insorgenza, durata, condizioni mediche preesistenti, farmaci assunti, etc."
          className="w-full h-36 p-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
          rows={5}
        ></textarea>
      </div>

      <div>
        <label htmlFor="parametriVitali" className="block text-md font-medium text-gray-700 mb-1">
          Parametri Vitali e Risultati Esami (Opzionale)
        </label>
        <input
          type="text"
          name="parametriVitali"
          id="parametriVitali"
          value={input.parametriVitali}
          onChange={handleChange}
          placeholder="Es: PA 140/90, FC 98bpm, SpO2 96%, ECG con sopraslivellamento ST"
          className="w-full p-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
        />
      </div>
    </div>
  );
};

export default DoctorInputForm;