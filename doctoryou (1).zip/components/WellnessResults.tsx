import React, { useRef, useState } from 'react';
import type { WellnessAnalysis } from '../types';
import { AlertTriangleIcon, LeafIcon, DumbbellIcon, FlameIcon, DownloadIcon, TestTube2Icon, LightbulbIcon, CrownIcon, SparklesIcon } from './icons';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import ShoppingList from './ShoppingList';

interface WellnessResultsProps {
  data: WellnessAnalysis;
  userTier: 'free' | 'pro';
  onUpgrade: () => void;
}

const UpgradeCTA: React.FC<{ onUpgrade: () => void, title: string, description: string, icon: React.ReactNode }> = ({ onUpgrade, title, description, icon }) => (
    <div className="bg-gradient-to-br from-teal-50 to-cyan-50 border-2 border-dashed border-teal-300 p-6 rounded-xl text-center mt-6">
        <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center mx-auto mb-3 shadow-md">
            {icon}
        </div>
        <h3 className="text-lg font-bold text-teal-800">{title}</h3>
        <p className="text-teal-700 mt-1 mb-4 text-sm">{description}</p>
        <button
            onClick={onUpgrade}
            className="inline-flex items-center px-6 py-2 bg-teal-500 text-white font-semibold rounded-lg shadow-md hover:bg-teal-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-all duration-300"
        >
            <CrownIcon className="h-5 w-5 mr-2" />
            Passa a PRO Ora
        </button>
    </div>
);

const WellnessResults: React.FC<WellnessResultsProps> = ({ data, userTier, onUpgrade }) => {
  const contentRef = useRef<HTMLDivElement>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const isPro = userTier === 'pro';

  const handleDownloadPdf = () => {
    if (!isPro) return;
    const input = contentRef.current;
    if (!input) return;

    setIsDownloading(true);

    html2canvas(input, {
        scale: 2, 
        useCORS: true, 
        backgroundColor: '#f1f5f9' // bg-slate-100/gray-100
    })
      .then((canvas) => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF({
          orientation: 'portrait',
          unit: 'mm',
          format: 'a4',
        });

        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        const margin = 15; 
        
        const contentWidth = pdfWidth - margin * 2;
        const pageContentHeight = pdfHeight - margin * 2;
        
        const canvasAspectRatio = canvas.height / canvas.width;
        let imgFinalHeight = contentWidth * canvasAspectRatio;
        
        const titleHeight = 20;
        const maxPages = 6;
        const maxAllowedContentHeight = (pageContentHeight * maxPages) - titleHeight;

        if (imgFinalHeight > maxAllowedContentHeight) {
            const scaleFactor = maxAllowedContentHeight / imgFinalHeight;
            imgFinalHeight *= scaleFactor;
        }

        let cursorY = margin;

        pdf.setFontSize(22);
        pdf.text("Il Tuo Piano Benessere Personalizzato", pdfWidth / 2, cursorY + 5, { align: 'center' });
        cursorY += titleHeight;

        pdf.addImage(imgData, 'PNG', margin, cursorY, contentWidth, imgFinalHeight);
        
        let heightLeft = imgFinalHeight;
        heightLeft -= (pdfHeight - cursorY - margin);

        let page = 1;
        while (heightLeft > 0 && page < maxPages) {
            pdf.addPage();
            page++;
            const newY = - (pageContentHeight * (page - 1)) - (pdfHeight - cursorY - margin);
            pdf.addImage(imgData, 'PNG', margin, newY, contentWidth, imgFinalHeight);
            heightLeft -= pageContentHeight;
        }

        pdf.save('piano-benessere-DoctorYou.pdf');
      })
      .catch((error) => {
        console.error("Errore durante la generazione del PDF:", error);
      })
      .finally(() => {
        setIsDownloading(false);
      });
  };

  return (
    <div className="space-y-8">
      <div className="bg-white p-4 rounded-xl shadow-lg border border-gray-200/80 flex justify-between items-center flex-wrap gap-4">
        <h2 className="text-xl font-bold text-gray-800">
            {isPro ? "Il Tuo Piano PRO Completo" : "Anteprima Piano Gratuito"}
        </h2>
        {isPro && (
            <button
              onClick={handleDownloadPdf}
              disabled={isDownloading}
              className="inline-flex items-center px-4 py-2 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition-all duration-300"
            >
              <DownloadIcon className="h-5 w-5 mr-2" />
              {isDownloading ? 'Creazione PDF...' : 'Scarica PDF'}
            </button>
        )}
      </div>
      
      <div ref={contentRef} className="space-y-8 p-4 bg-gray-50/50 rounded-lg">
        <div className="bg-amber-50 border-l-4 border-amber-400 text-amber-900 p-4 rounded-r-lg" role="alert">
          <div className="flex">
            <div className="py-1"><AlertTriangleIcon className="h-6 w-6 text-amber-500 mr-4"/></div>
            <div>
              <p className="font-bold">Disclaimer Importante</p>
              <p className="text-sm">{data.disclaimer}</p>
            </div>
          </div>
        </div>
        
        {data.dietaConsigliata && (
          <div className="bg-indigo-50 border-l-4 border-indigo-400 text-indigo-900 p-6 rounded-r-lg shadow-md">
            <div className="flex">
              <div className="py-1"><LightbulbIcon className="h-8 w-8 text-indigo-500 mr-5 flex-shrink-0" /></div>
              <div>
                <h2 className="text-xl font-bold mb-2">Il Consiglio dell'IA: Dieta {data.dietaConsigliata.nome}</h2>
                <p className="text-md">{data.dietaConsigliata.motivazione}</p>
              </div>
            </div>
          </div>
        )}

        {data.fabbisognoCaloricoGiornaliero && (
          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200/80">
              <div className="flex items-center">
                  <FlameIcon className="h-10 w-10 text-orange-500 mr-4"/>
                  <div>
                      <h2 className="text-xl font-bold text-gray-800">Fabbisogno Calorico Giornaliero Stimato</h2>
                      <p className="text-3xl font-bold text-orange-600">{data.fabbisognoCaloricoGiornaliero.valore} kcal</p>
                      <p className="text-sm text-gray-500 mt-1">{data.fabbisognoCaloricoGiornaliero.spiegazione}</p>
                  </div>
              </div>
          </div>
        )}

        {isPro ? (
            data.listaSpesa && data.listaSpesa.length > 0 && <ShoppingList items={data.listaSpesa} cost={data.costoApprossimativo} />
        ) : (
            <UpgradeCTA 
                onUpgrade={onUpgrade} 
                title="Sblocca la Lista della Spesa e la Stima dei Costi"
                description="Passa a PRO per ricevere una lista della spesa completa per 14 giorni e una stima dei costi, risparmiando tempo e denaro."
                icon={<SparklesIcon className="h-6 w-6 text-teal-600" />} 
            />
        )}


        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 space-y-8">
             {data.suggerimentiIntegratori && data.suggerimentiIntegratori.length > 0 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-gray-800 border-b-2 border-gray-200 pb-2 flex items-center">
                    <TestTube2Icon className="h-7 w-7 mr-3 text-teal-600"/>
                    Integratori Consigliati
                  </h2>
                  <div className="space-y-4">
                    {data.suggerimentiIntegratori.map((supplement, index) => (
                      <div key={index} className="bg-white p-5 rounded-xl shadow-md border border-gray-200/80">
                        <h3 className="text-lg font-semibold text-teal-800 mb-2">{supplement.nome}</h3>
                        <p className="text-gray-600 mb-2"><span className="font-semibold">Scopo:</span> {supplement.scopo}</p>
                        <p className="text-sm font-medium text-gray-600 bg-gray-100 inline-block px-2 py-1 rounded">
                            {supplement.dosaggioConsigliato}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-800 border-b-2 border-gray-200 pb-2 flex items-center">
                <DumbbellIcon className="h-7 w-7 mr-3 text-indigo-600"/>
                Piano di Attività Fisica
              </h2>
              <div className="space-y-4">
                {data.suggerimentiAttivitaFisica.map((activity, index) => (
                  <div key={index} className="bg-white p-5 rounded-xl shadow-md border border-gray-200/80">
                    <h3 className="text-lg font-semibold text-indigo-800 mb-2">{activity.tipo}</h3>
                    <p className="text-gray-600 mb-2">{activity.descrizione}</p>
                    <p className="text-sm font-medium text-gray-600 bg-gray-100 inline-block px-2 py-1 rounded">
                        Frequenza: {activity.frequenza}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-2 space-y-6">
            <h2 className="text-2xl font-bold text-gray-800 border-b-2 border-gray-200 pb-2 flex items-center">
              <LeafIcon className="h-7 w-7 mr-3 text-green-600"/>
               {isPro ? "Piano Alimentare di 14 Giorni" : "Piano Alimentare di 1 Giorno (Anteprima)"}
            </h2>
            <div className="space-y-6">
              {data.pianoAlimentare.map((dailyPlan) => (
                <div key={dailyPlan.giorno} className="bg-white p-5 rounded-xl shadow-md border border-gray-200/80">
                   <h3 className="text-xl font-bold text-indigo-700 mb-4">Giorno {dailyPlan.giorno}</h3>
                   <div className="space-y-4">
                      {dailyPlan.pasti.map((meal, index) => (
                        <div key={index} className="border-t border-gray-200 pt-3">
                          <div className="flex justify-between items-start gap-4">
                              <h4 className="text-lg font-semibold text-green-800 mb-1">{meal.pasto}</h4>
                              <span className="text-sm font-bold text-green-700 bg-green-100 px-3 py-1 rounded-full whitespace-nowrap">{meal.calorieStimate} kcal</span>
                          </div>
                          <p className="text-gray-600">{meal.descrizione}</p>
                        </div>
                      ))}
                   </div>
                </div>
              ))}
            </div>
             {!isPro && (
                 <UpgradeCTA 
                    onUpgrade={onUpgrade}
                    title="Ottieni il Piano Completo di 14 Giorni!"
                    description="Il tuo piano gratuito è un assaggio. Passa a PRO per sbloccare due settimane intere di piano alimentare dettagliato."
                    icon={<SparklesIcon className="h-6 w-6 text-teal-600" />}
                />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WellnessResults;