import React from 'react';
import type { PatientInputState } from '../types';

interface PatientInputFormProps {
  input: PatientInputState;
  setInput: (input: PatientInputState) => void;
}

const sintomiComuni = [
    "Febbre", "Tosse", "Mal di gola", "Congestione nasale", "Naso che cola",
    "Mal di testa", "Dolori muscolari/articolari", "Stanchezza/Affaticamento",
    "Nausea/Vomito", "Diarrea", "Dolore addominale", "Eruzione cutanea", "Fiato corto"
];

const PatientInputForm: React.FC<PatientInputFormProps> = ({ input, setInput }) => {
  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput({ ...input, [e.target.name]: e.target.value });
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value, checked } = e.target;
    setInput({
      ...input,
      sintomiSelezionati: checked
        ? [...input.sintomiSelezionati, value]
        : input.sintomiSelezionati.filter((s) => s !== value),
    });
  };

  return (
    <div className="space-y-6">
        <div className="space-y-4 rounded-lg border border-gray-200 p-4 bg-gray-50">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {sintomiComuni.map((sintomo) => (
                    <label key={sintomo} className="flex items-center p-3 rounded-lg hover:bg-indigo-50 transition-colors cursor-pointer border border-gray-200">
                        <input
                            type="checkbox"
                            value={sintomo}
                            checked={input.sintomiSelezionati.includes(sintomo)}
                            onChange={handleCheckboxChange}
                            className="h-5 w-5 rounded border-gray-400 text-indigo-600 focus:ring-indigo-500 mr-3"
                        />
                        <span className="text-gray-700 select-none">{sintomo}</span>
                    </label>
                ))}
            </div>
        </div>

        <div>
            <label htmlFor="altriSintomi" className="block text-md font-medium text-gray-700 mb-1">
              Altri sintomi o dettagli (opzionale)
            </label>
            <textarea
              name="altriSintomi"
              id="altriSintomi"
              value={input.altriSintomi}
              onChange={handleChange}
              placeholder="Descrivi qui qualsiasi altro sintomo o fornisci maggiori dettagli (es. da quanto tempo hai la febbre, il tipo di tosse, ecc.)"
              className="w-full h-28 p-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
              rows={4}
            ></textarea>
        </div>
    </div>
  );
};

export default PatientInputForm;