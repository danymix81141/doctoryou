import React from 'react';
import { ViewMode } from '../types';
import { StethoscopeIcon, HeartPulseIcon, LineChartIcon } from './icons';

interface ViewToggleProps {
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
}

const buttons = [
  { mode: ViewMode.Patient, label: 'Paziente', icon: <StethoscopeIcon className="w-5 h-5" /> },
  { mode: ViewMode.Doctor, label: 'Medico', icon: <StethoscopeIcon className="w-5 h-5" /> },
  { mode: ViewMode.Wellness, label: 'Benessere', icon: <HeartPulseIcon className="w-5 h-5" /> },
  { mode: ViewMode.Progress, label: 'Progressi', icon: <LineChartIcon className="w-5 h-5" /> },
];

const ViewToggle: React.FC<ViewToggleProps> = ({ viewMode, setViewMode }) => {
  return (
    <div className="flex items-center justify-center p-1 bg-gray-200/80 rounded-full shadow-inner flex-wrap gap-1">
      {buttons.map(({ mode, label, icon }) => (
        <button
          key={mode}
          onClick={() => setViewMode(mode)}
          className={`flex items-center justify-center gap-2 px-3 md:px-4 py-2 text-sm font-semibold rounded-full transition-all duration-300 transform focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-opacity-50 ${
            viewMode === mode 
              ? 'bg-white text-indigo-600 shadow-md scale-105' 
              : 'text-gray-600 hover:bg-gray-300/60 hover:text-gray-800'
          }`}
          aria-pressed={viewMode === mode}
        >
          {icon}
          <span>{label}</span>
        </button>
      ))}
    </div>
  );
};

export default ViewToggle;