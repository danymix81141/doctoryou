
import React, { useState } from 'react';
import type { ShoppingListItem, WellnessAnalysis } from '../types';
import { ShoppingCartIcon, EuroIcon } from './icons';

interface ShoppingListProps {
  items: ShoppingListItem[];
  cost?: WellnessAnalysis['costoApprossimativo'];
}

const ShoppingList: React.FC<ShoppingListProps> = ({ items, cost }) => {
  const [checkedItems, setCheckedItems] = useState<Set<string>>(new Set());

  const handleToggle = (itemName: string) => {
    const newCheckedItems = new Set(checkedItems);
    if (newCheckedItems.has(itemName)) {
      newCheckedItems.delete(itemName);
    } else {
      newCheckedItems.add(itemName);
    }
    setCheckedItems(newCheckedItems);
  };

  if (!items || items.length === 0) {
    return null;
  }

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-gray-800 border-b-2 border-gray-200 pb-2 flex items-center">
            <ShoppingCartIcon className="h-7 w-7 mr-3 text-amber-600"/>
            Lista della Spesa (14 Giorni)
        </h2>
        
        {cost && cost.valore > 0 && (
            <div className="bg-green-50 border-l-4 border-green-400 text-green-900 p-4 rounded-r-lg">
                <div className="flex">
                    <div className="py-1"><EuroIcon className="h-6 w-6 text-green-500 mr-4"/></div>
                    <div>
                        <p className="font-bold">Costo Totale Stimato: {new Intl.NumberFormat('it-IT', { style: 'currency', currency: cost.valuta || 'EUR' }).format(cost.valore)}</p>
                        <p className="text-sm mt-1">{cost.spiegazione}</p>
                    </div>
                </div>
            </div>
        )}
      </div>

      <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200/80">
         <p className="text-sm text-gray-600 mb-4">Ecco la lista aggregata di tutto ciò che ti serve per il tuo piano. Spunta gli ingredienti man mano che li acquisti.</p>
         <ul className="space-y-3 columns-1 sm:columns-2 lg:columns-3 gap-x-8">
            {items.map((item, index) => (
                <li key={index} className="flex items-center break-inside-avoid-column">
                    <label className="flex items-start cursor-pointer w-full group">
                         <input
                            type="checkbox"
                            checked={checkedItems.has(item.ingrediente)}
                            onChange={() => handleToggle(item.ingrediente)}
                            className="h-5 w-5 rounded border-gray-400 text-indigo-600 focus:ring-indigo-500 mr-3 mt-1 flex-shrink-0"
                        />
                        <span className={`flex-grow text-gray-700 group-hover:text-indigo-700 transition-colors ${checkedItems.has(item.ingrediente) ? 'line-through text-gray-400' : ''}`}>
                            {item.ingrediente}
                            <span className="font-medium text-gray-500 ml-1.5">({item.quantita})</span>
                        </span>
                    </label>
                </li>
            ))}
         </ul>
      </div>
    </div>
  );
};

export default ShoppingList;