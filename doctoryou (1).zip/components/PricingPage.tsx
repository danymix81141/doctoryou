import React from 'react';
import { CrownIcon, CheckIcon, SparklesIcon } from './icons';

interface PricingPageProps {
  onBack: () => void;
}

const FeatureItem: React.FC<{ children: React.ReactNode, isIncluded: boolean }> = ({ children, isIncluded }) => (
    <li className="flex items-start">
        <div className={`w-5 h-5 rounded-full flex items-center justify-center mr-3 mt-0.5 flex-shrink-0 ${isIncluded ? 'bg-green-500' : 'bg-gray-300'}`}>
            <CheckIcon className={`w-3 h-3 ${isIncluded ? 'text-white' : 'text-gray-500'}`} />
        </div>
        <span className={isIncluded ? "text-gray-700" : "text-gray-500 line-through"}>{children}</span>
    </li>
);

const PricingPage: React.FC<PricingPageProps> = ({ onBack }) => {

    const monthlyLink = "https://www.paypal.com/ncp/payment/DSGT9L8GDCJ56";
    const yearlyLink = "https://www.paypal.com/ncp/payment/55PARMDHS3RLW";

  return (
    <div className="bg-white p-6 sm:p-8 rounded-xl shadow-lg border border-gray-200/80 w-full max-w-4xl mx-auto">
        <div className="text-center mb-10">
            <h1 className="text-4xl font-bold text-indigo-700 tracking-tight">Scegli il Piano Adatto a Te</h1>
            <p className="mt-3 text-lg text-gray-600 max-w-2xl mx-auto">Sblocca tutte le funzionalità con il piano PRO e raggiungi i tuoi obiettivi più velocemente.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* FREE PLAN */}
            <div className="border border-gray-200 rounded-lg p-6 flex flex-col bg-gray-50/50">
                <h2 className="text-2xl font-bold text-gray-800">Free</h2>
                <p className="text-gray-500 mt-2 mb-6">L'essenziale per iniziare il tuo percorso</p>
                <p className="text-4xl font-bold text-gray-900 mb-6">€0</p>
                <ul className="space-y-4 mb-8 flex-grow">
                    <FeatureItem isIncluded={true}>Analisi Sintomi (Paziente/Medico)</FeatureItem>
                    <FeatureItem isIncluded={true}>Tracciamento Progressi</FeatureItem>
                    <FeatureItem isIncluded={true}>Piano Benessere di 1 Giorno (Anteprima)</FeatureItem>
                    <FeatureItem isIncluded={false}>Piano di 14 giorni Completo</FeatureItem>
                    <FeatureItem isIncluded={false}>Lista della Spesa Automatica</FeatureItem>
                    <FeatureItem isIncluded={false}>Stima Costi Spesa</FeatureItem>
                    <FeatureItem isIncluded={false}>Download Piano in PDF</FeatureItem>
                </ul>
                <button 
                    disabled
                    className="w-full py-3 bg-gray-200 text-gray-700 font-semibold rounded-lg transition-colors cursor-not-allowed"
                >
                    Il Tuo Piano Attuale
                </button>
            </div>

            {/* PRO PLAN */}
            <div className="border-2 border-indigo-600 rounded-lg p-6 flex flex-col relative shadow-2xl bg-gradient-to-br from-indigo-50 to-white">
                <div className="absolute top-0 -translate-y-1/2 w-full flex justify-center">
                    <span className="bg-indigo-600 text-white text-xs font-bold uppercase px-4 py-1 rounded-full">Più Popolare</span>
                </div>
                <h2 className="text-2xl font-bold text-indigo-700 flex items-center"><CrownIcon className="w-6 h-6 mr-2" /> PRO</h2>
                <p className="text-gray-500 mt-2 mb-6">L'esperienza completa per risultati seri</p>
                
                <div className="bg-white border border-gray-200 p-4 rounded-lg text-center mb-6">
                     <p className="text-gray-800"><span className="font-bold text-indigo-700 text-xl">PRO Mensile</span> o scegli l'annuale e <span className="font-bold text-green-600">risparmia!</span></p>
                </div>

                <ul className="space-y-4 mb-8 flex-grow">
                    <FeatureItem isIncluded={true}>Analisi Sintomi (Paziente/Medico)</FeatureItem>
                    <FeatureItem isIncluded={true}>Tracciamento Progressi</FeatureItem>
                    <FeatureItem isIncluded={true}>Piano Benessere di 1 Giorno (Anteprima)</FeatureItem>
                    <FeatureItem isIncluded={true}><span className="font-bold text-indigo-800">Piano di 14 giorni Completo</span></FeatureItem>
                    <FeatureItem isIncluded={true}><span className="font-bold text-indigo-800">Lista della Spesa Automatica</span></FeatureItem>
                    <FeatureItem isIncluded={true}><span className="font-bold text-indigo-800">Stima Costi Spesa</span></FeatureItem>
                    <FeatureItem isIncluded={true}><span className="font-bold text-indigo-800">Download Piano in PDF</span></FeatureItem>
                </ul>
                <div className="space-y-4">
                     <a 
                        href={monthlyLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full block text-center py-3 bg-white text-indigo-700 font-semibold rounded-lg border border-gray-300 hover:bg-gray-100 transition-colors"
                     >
                        Vai al Piano Mensile
                    </a>
                    <a 
                        href={yearlyLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full block text-center py-3 bg-teal-500 text-white font-semibold rounded-lg hover:bg-teal-600 transition-colors shadow-lg"
                    >
                        <SparklesIcon className="w-5 h-5 inline-block mr-2" />
                        Vai al Piano Annuale (Consigliato)
                    </a>
                </div>
            </div>
        </div>

        <div className="text-center mt-10">
            <button onClick={onBack} className="text-gray-600 hover:text-indigo-700 font-semibold transition-colors">
                &larr; Torna all'app
            </button>
        </div>
        <p className="text-center text-xs text-gray-400 mt-6">
            Sarai reindirizzato a PayPal per completare il pagamento in modo sicuro. L'aggiornamento del piano nell'app è simulato e deve essere effettuato manualmente dall'amministratore dopo il pagamento.
        </p>
    </div>
  );
};

export default PricingPage;