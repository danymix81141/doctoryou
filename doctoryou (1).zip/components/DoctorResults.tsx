
import React, { useState, useEffect } from 'react';
import type { DoctorAnalysis } from '../types';
import { ClipboardIcon, CheckIcon, AlertTriangleIcon } from './icons';

interface DoctorResultsProps {
  data: DoctorAnalysis;
}

const DoctorResults: React.FC<DoctorResultsProps> = ({ data }) => {
  const [referralText, setReferralText] = useState(data.suggestedReferral || '');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setReferralText(data.suggestedReferral || '');
  }, [data.suggestedReferral]);
  
  const handleCopy = () => {
    navigator.clipboard.writeText(referralText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8">
      {data.disclaimer && (
        <div className="bg-indigo-50 border-l-4 border-indigo-400 text-indigo-900 p-4 rounded-r-lg" role="alert">
          <div className="flex">
            <div className="py-1"><AlertTriangleIcon className="h-6 w-6 text-indigo-500 mr-4"/></div>
            <div>
              <p className="font-bold">Disclaimer per Professionisti</p>
              <p className="text-sm">{data.disclaimer}</p>
            </div>
          </div>
        </div>
      )}

      <div>
        <h2 className="text-3xl font-bold text-gray-800 border-b-2 border-gray-200 pb-3 mb-6">Analisi Clinica Avanzata</h2>
        <div className="bg-white p-1 rounded-xl shadow-lg border border-gray-200/80">
          <div className="overflow-x-auto">
            <table className="w-full text-left table-auto">
              <thead className="bg-gray-50 text-gray-500 uppercase text-sm">
                <tr>
                  <th className="p-4 font-semibold rounded-tl-lg">Condizione</th>
                  <th className="p-4 font-semibold">Codice ICD-10</th>
                  <th className="p-4 font-semibold">Farmaci/Trattamenti</th>
                  <th className="p-4 font-semibold rounded-tr-lg">Approfondimenti Clinici</th>
                </tr>
              </thead>
              <tbody className="text-gray-700">
                {data.differentialDiagnosis.map((diag, index) => (
                  <tr key={index} className="border-t border-gray-200 hover:bg-gray-50/70">
                    <td className="p-4 font-medium text-indigo-800">{diag.condition}</td>
                    <td className="p-4"><code className="font-mono bg-gray-100 text-gray-800 px-2 py-1 rounded-md text-sm">{diag.icd10Code}</code></td>
                    <td className="p-4">
                      <ul className="list-disc list-inside space-y-1">
                        {diag.medications.map((med, i) => <li key={i}>{med}</li>)}
                      </ul>
                    </td>
                    <td className="p-4 text-sm">{diag.clinicalInsights}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div>
          <h2 className="text-3xl font-bold text-gray-800 border-b-2 border-gray-200 pb-3 mb-6">Bozza di Richiesta Medica</h2>
          <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200/80 space-y-4">
            <p className="text-sm text-gray-600">
                L'IA ha generato la seguente bozza. Puoi modificarla direttamente qui e copiarla per utilizzarla nei tuoi sistemi.
            </p>
            <textarea
                value={referralText}
                onChange={(e) => setReferralText(e.target.value)}
                className="w-full h-48 p-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                aria-label="Bozza di richiesta medica"
            />
            <div className="flex justify-end">
                <button
                    onClick={handleCopy}
                    className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white transition-colors duration-150 ${
                        copied ? 'bg-green-600 hover:bg-green-700' : 'bg-indigo-600 hover:bg-indigo-700'
                    } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500`}
                >
                    {copied ? (
                        <>
                            <CheckIcon className="h-5 w-5 mr-2" />
                            Copiato!
                        </>
                    ) : (
                        <>
                            <ClipboardIcon className="h-5 w-5 mr-2" />
                            Copia Testo
                        </>
                    )}
                </button>
            </div>
          </div>
      </div>
    </div>
  );
};

export default DoctorResults;