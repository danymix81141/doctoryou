import React from 'react';
import type { WellnessInputState } from '../types';
import { BookOpenIcon } from './icons';

interface WellnessInputFormProps {
  input: WellnessInputState;
  setInput: (input: WellnessInputState) => void;
  onShowDietLibrary: () => void;
}

const condizioniOptions = [
    "Pressione alta (Ipertensione)",
    "Pressione bassa (Ipotensione)",
    "Glicemia alta (Diabete)",
    "Glicemia bassa (Ipoglicemia)",
    "Colesterolo alto",
    "Artrite",
    "Problemi alla tiroide",
];

const obiettivoOptions: { value: WellnessInputState['obiettivo'], label: string }[] = [
    { value: '', label: "Seleziona un obiettivo" },
    { value: 'dimagrire', label: 'Dimagrire' },
    { value: 'ingrassare', label: 'Aumentare di peso' },
    { value: 'aumentare_massa_muscolare', label: 'Aumentare massa muscolare' },
    { value: 'migliorare_salute', label: 'Migliorare la salute generale' },
    { value: 'gestire_patologie', label: 'Gestire intolleranze o patologie' },
];

const stileAlimentareOptions: { value: WellnessInputState['stileAlimentare'], label: string }[] = [
    { value: '', label: 'Seleziona uno stile' },
    { value: 'onnivoro', label: 'Onnivoro' },
    { value: 'vegetariano', label: 'Vegetariano' },
    { value: 'vegano', label: 'Vegano' },
];

const dietaOptions = [
    { value: '', label: "Lascia che l'IA scelga per me" },
    { value: 'Dieta Mediterranea', label: 'Dieta Mediterranea' },
    { value: 'Dieta Chetogenica', label: 'Dieta Chetogenica' },
    { value: 'Dieta Vegana', label: 'Dieta Vegana' },
    { value: 'Dieta Vegetariana', label: 'Dieta Vegetariana' },
    { value: 'Dieta Paleo', label: 'Dieta Paleo' },
    { value: 'Dieta DASH', label: 'Dieta DASH' },
    { value: 'Dieta a Basso Contenuto di FODMAP', label: 'Dieta a Basso Contenuto di FODMAP' },
    { value: 'Digiuno Intermittente', label: 'Digiuno Intermittente' },
    { value: 'Dieta Dukan', label: 'Dieta Dukan' },
];


const WellnessInputForm: React.FC<WellnessInputFormProps> = ({ input, setInput, onShowDietLibrary }) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setInput({ ...input, [e.target.name]: e.target.value });
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value, checked } = e.target;
    setInput({
      ...input,
      condizioniMediche: checked
        ? [...input.condizioniMediche, value]
        : input.condizioniMediche.filter((cond) => cond !== value),
    });
  };
  
  const formControlStyle = "w-full p-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition";

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
         <div>
          <label htmlFor="eta" className="block text-md font-medium text-gray-700 mb-1">
            Età
          </label>
          <input type="number" name="eta" id="eta" value={input.eta} onChange={handleChange} placeholder="Es: 30" className={formControlStyle} />
        </div>
        <div>
          <label htmlFor="sesso" className="block text-md font-medium text-gray-700 mb-1">
            Sesso Biologico
          </label>
          <select name="sesso" id="sesso" value={input.sesso} onChange={handleChange} className={formControlStyle} >
            <option value="">Non specificato</option>
            <option value="Maschio">Maschio</option>
            <option value="Femmina">Femmina</option>
          </select>
        </div>
      </div>
      
       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="altezza" className="block text-md font-medium text-gray-700 mb-1">
            Altezza (cm)
          </label>
          <input type="number" name="altezza" id="altezza" value={input.altezza} onChange={handleChange} placeholder="Es: 175" className={formControlStyle} />
        </div>
        <div>
          <label htmlFor="peso" className="block text-md font-medium text-gray-700 mb-1">
            Peso (kg)
          </label>
          <input type="number" name="peso" id="peso" value={input.peso} onChange={handleChange} placeholder="Es: 70" className={formControlStyle} />
        </div>
      </div>

       <div>
          <label htmlFor="livelloAttivita" className="block text-md font-medium text-gray-700 mb-1">
            Livello di Attività Fisica
          </label>
          <select name="livelloAttivita" id="livelloAttivita" value={input.livelloAttivita} onChange={handleChange} className={formControlStyle} >
            <option value="">Seleziona un'opzione</option>
            <option value="sedentario">Sedentario (poco o nessun esercizio)</option>
            <option value="leggero">Leggero (esercizio 1-3 giorni/settimana)</option>
            <option value="attivo">Attivo (esercizio 3-5 giorni/settimana)</option>
            <option value="molto_attivo">Molto Attivo (esercizio intenso 6-7 giorni/settimana)</option>
          </select>
        </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
         <div>
          <label htmlFor="obiettivo" className="block text-md font-medium text-gray-700 mb-1">
            Obiettivo Principale
          </label>
          <select name="obiettivo" id="obiettivo" value={input.obiettivo} onChange={handleChange} className={formControlStyle} required >
            {obiettivoOptions.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="stileAlimentare" className="block text-md font-medium text-gray-700 mb-1">
            Stile Alimentare
          </label>
          <select name="stileAlimentare" id="stileAlimentare" value={input.stileAlimentare} onChange={handleChange} className={formControlStyle} >
            {stileAlimentareOptions.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
          </select>
        </div>
      </div>
      
       <div>
            <div className="flex justify-between items-center mb-1">
                <label htmlFor="dietaScelta" className="block text-md font-medium text-gray-700">
                Scegli la Dieta (o lascia scegliere all'IA)
                </label>
                <button
                type="button"
                onClick={onShowDietLibrary}
                className="inline-flex items-center text-sm font-semibold text-indigo-600 hover:text-indigo-700 hover:underline focus:outline-none"
                >
                <BookOpenIcon className="h-5 w-5 mr-1.5 flex-shrink-0" />
                Libreria Diete
                </button>
            </div>
            <select name="dietaScelta" id="dietaScelta" value={input.dietaScelta} onChange={handleChange} className={formControlStyle}>
                {dietaOptions.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
            </select>
        </div>

      <div className="space-y-4 rounded-lg border border-gray-200 p-4 bg-gray-50">
        <div>
            <label className="block text-md font-medium text-gray-700 mb-3">
              Condizioni Mediche (se presenti)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {condizioniOptions.map((condizione) => (
                    <label key={condizione} className="flex items-center p-3 rounded-lg hover:bg-indigo-50 transition-colors cursor-pointer border border-gray-200">
                        <input
                            type="checkbox"
                            value={condizione}
                            checked={input.condizioniMediche.includes(condizione)}
                            onChange={handleCheckboxChange}
                            className="h-5 w-5 rounded border-gray-400 text-indigo-600 focus:ring-indigo-500 mr-3"
                        />
                        <span className="text-gray-700 select-none">{condizione}</span>
                    </label>
                ))}
            </div>
        </div>

         <div>
          <label htmlFor="allergieEPreferenze" className="block text-md font-medium text-gray-700 mb-1">
            Allergie o Preferenze Specifiche
          </label>
          <input type="text" name="allergieEPreferenze" id="allergieEPreferenze" value={input.allergieEPreferenze} onChange={handleChange} placeholder="Es: Vegetariano, allergia alle noci, intolleranza al lattosio" className={formControlStyle} />
        </div>
      </div>
    </div>
  );
};

export default WellnessInputForm;