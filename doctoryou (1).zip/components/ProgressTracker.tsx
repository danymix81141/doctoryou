import React, { useState } from 'react';
import type { ProgressEntry } from '../types';
import { LineChartIcon } from './icons';

interface ProgressTrackerProps {
  entries: ProgressEntry[];
  onAddEntry: (newEntry: { weight: number; notes?: string }) => void;
}

const ProgressTracker: React.FC<ProgressTrackerProps> = ({ entries, onAddEntry }) => {
  const [weight, setWeight] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const weightValue = parseFloat(weight);
    if (!weight || isNaN(weightValue) || weightValue <= 0) {
      setError('Inserisci un valore di peso valido.');
      return;
    }
    setError(null);
    onAddEntry({ weight: weightValue, notes });
    setWeight('');
    setNotes('');
  };

  const getWeightChange = (index: number): { change: string; color: string } => {
    if (index >= entries.length - 1) {
      return { change: '-', color: 'text-gray-500' };
    }
    const currentWeight = entries[index].weight;
    const previousWeight = entries[index + 1].weight;
    const diff = currentWeight - previousWeight;

    if (diff < 0) {
      return { change: `${diff.toFixed(1)} kg`, color: 'text-green-600' };
    }
    if (diff > 0) {
      return { change: `+${diff.toFixed(1)} kg`, color: 'text-red-600' };
    }
    return { change: '0.0 kg', color: 'text-gray-500' };
  };

  const formControlStyle = "w-full p-3 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition";

  return (
    <div className="space-y-8">
      <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200/80">
        <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
          <LineChartIcon className="h-7 w-7 mr-3 text-indigo-600"/>
          Traccia i Tuoi Progressi
        </h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-1">
              <label htmlFor="progress-weight" className="block text-md font-medium text-gray-700 mb-1">
                Peso Attuale (kg)
              </label>
              <input
                type="number"
                id="progress-weight"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                placeholder="Es: 70.5"
                className={formControlStyle}
                step="0.1"
              />
            </div>
            <div className="md:col-span-2">
              <label htmlFor="progress-notes" className="block text-md font-medium text-gray-700 mb-1">
                Note (opzionale)
              </label>
              <input
                type="text"
                id="progress-notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Es: Mi sento pieno di energia!"
                className={formControlStyle}
              />
            </div>
          </div>
          {error && <p className="text-red-600 text-sm mt-2">{error}</p>}
          <div className="flex justify-end mt-2">
            <button
              type="submit"
              className="px-6 py-2 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
            >
              Salva Progresso
            </button>
          </div>
        </form>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200/80">
          <h3 className="text-xl font-bold text-gray-800 mb-4">Storico dei Progressi</h3>
          {entries.length === 0 ? (
            <p className="text-gray-500 text-center py-8">Nessun progresso registrato. Aggiungi la tua prima misurazione per iniziare!</p>
          ) : (
            <div className="overflow-x-auto">
                <table className="w-full text-left table-auto">
                    <thead className="bg-gray-50 text-gray-500 uppercase text-sm">
                        <tr>
                            <th className="p-4 font-semibold">Data</th>
                            <th className="p-4 font-semibold text-right">Peso (kg)</th>
                            <th className="p-4 font-semibold text-right">Variazione</th>
                            <th className="p-4 font-semibold">Note</th>
                        </tr>
                    </thead>
                    <tbody className="text-gray-700">
                        {entries.map((entry, index) => {
                            const { change, color } = getWeightChange(index);
                            return (
                                <tr key={entry.id} className="border-t border-gray-200 hover:bg-gray-50/70">
                                    <td className="p-4 font-medium">{entry.date}</td>
                                    <td className="p-4 font-medium text-right">{entry.weight.toFixed(1)}</td>
                                    <td className={`p-4 font-bold text-right ${color}`}>{change}</td>
                                    <td className="p-4 text-sm text-gray-600 italic">{entry.notes || '-'}</td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
          )}
      </div>
    </div>
  );
};

export default ProgressTracker;