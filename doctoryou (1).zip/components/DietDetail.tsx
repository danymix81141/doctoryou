import React from 'react';
import type { DietDetail as DietDetailType } from '../types';
import { LeafIcon, AlertTriangleIcon } from './icons';

interface DietDetailProps {
  diet: DietDetailType;
  onBack: () => void;
}

// Define an interface for the color configuration
interface ColorConfig {
    border: string;
    text: string;
    bg?: string;
    icon?: React.ReactNode;
}

const SectionCard: React.FC<{ title: string; items: string[]; color: 'indigo' | 'green' | 'amber' }> = ({ title, items, color }) => {
    // Use the interface to type the colors object
    const colors: Record<'indigo' | 'green' | 'amber', ColorConfig> = {
        indigo: { border: 'border-indigo-200', text: 'text-indigo-800' },
        green: { border: 'border-green-200', text: 'text-green-800' },
        amber: { border: 'border-amber-400', text: 'text-amber-800', bg: 'bg-amber-50', icon: <AlertTriangleIcon className="h-6 w-6 mr-3"/> },
    };
    const selectedColor = colors[color];
    
    return (
        <div className={`space-y-4 ${selectedColor.bg ? `${selectedColor.bg} p-4 rounded-lg border-l-4 ${selectedColor.border}` : ''}`}>
          <h3 className={`text-xl font-semibold ${selectedColor.text} ${!selectedColor.bg ? `border-b-2 pb-2 ${selectedColor.border}` : 'flex items-center'}`}>
            {selectedColor.icon}
            {title}
          </h3>
          <ul className="list-disc list-inside space-y-2 text-gray-700">
            {items.map((item, i) => <li key={i}>{item}</li>)}
          </ul>
        </div>
    )
};


const DietDetail: React.FC<DietDetailProps> = ({ diet, onBack }) => {
  return (
    <div className="bg-white p-6 sm:p-8 rounded-xl shadow-lg border border-gray-200/80 space-y-8">
      <div className="flex justify-between items-start flex-wrap gap-4">
        <h2 className="text-3xl font-bold text-indigo-700">{diet.nome}</h2>
        <button
          onClick={onBack}
          className="px-4 py-2 bg-gray-200 text-gray-700 font-semibold rounded-lg hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
        >
          &larr; Torna alla lista
        </button>
      </div>
      
      <p className="text-lg text-gray-600 italic border-l-4 border-gray-300 pl-4">{diet.descrizione}</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <SectionCard title="Principi Chiave" items={diet.principiChiave} color="indigo" />
        <SectionCard title="Potenziali Benefici" items={diet.potenzialiBenefici} color="green" />
      </div>
      
      <SectionCard title="Rischi e Considerazioni" items={diet.rischiEConsiderazioni} color="amber" />
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
            <h3 className="text-xl font-semibold text-gray-800 border-b-2 border-gray-200 pb-2">Alimenti Consigliati</h3>
            <ul className="list-disc list-inside space-y-2 text-gray-700 mt-4">
                {diet.alimentiConsigliati.map((item, i) => <li key={i}>{item}</li>)}
            </ul>
        </div>
        <div>
            <h3 className="text-xl font-semibold text-gray-800 border-b-2 border-gray-200 pb-2">Alimenti da Evitare</h3>
            <ul className="list-disc list-inside space-y-2 text-gray-700 mt-4">
                {diet.alimentiDaEvitare.map((item, i) => <li key={i}>{item}</li>)}
            </ul>
        </div>
      </div>
      
      <div className="space-y-4">
        <h3 className="text-xl font-semibold text-gray-800 border-b-2 border-gray-200 pb-2 flex items-center">
            <LeafIcon className="h-6 w-6 mr-3 text-green-600"/>
            Esempio di Piano Giornaliero
        </h3>
        <div className="space-y-3">
            {diet.esempioPianoGiornaliero.map((meal, i) => (
                <div key={i} className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                    <p className="font-semibold text-green-800">{meal.pasto}</p>
                    <p className="text-gray-600">{meal.descrizione}</p>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default DietDetail;