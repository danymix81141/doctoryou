import React, { useState, useCallback, useEffect } from 'react';
import { ViewMode } from './types';
import type { PatientAnalysis, DoctorAnalysis, DoctorInputState, WellnessAnalysis, WellnessInputState, ProgressEntry, User, UserData, PatientInputState } from './types';
import { getPatientAnalysis, getDoctorAnalysis, getWellnessAnalysis } from './services/geminiService';
import * as db from './services/databaseService';
import * as auth from './services/authService';
import ViewToggle from './components/ViewToggle';
import LoadingSpinner from './components/LoadingSpinner';
import PatientResults from './components/PatientResults';
import DoctorResults from './components/DoctorResults';
import DoctorInputForm from './components/DoctorInputForm';
import PatientInputForm from './components/PatientInputForm';
import WellnessInputForm from './components/WellnessInputForm';
import WellnessResults from './components/WellnessResults';
import ProgressTracker from './components/ProgressTracker';
import AdminPanel from './components/AdminPanel';
import AdminLogin from './components/AdminLogin';
import UserAuth from './components/UserAuth';
import PricingPage from './components/PricingPage';
import DietLibrary from './components/DietLibrary';
import { StethoscopeIcon, HeartPulseIcon, UserCircle2Icon, LogOutIcon, CrownIcon } from './components/icons';

const App: React.FC = () => {
  // Global App State
  const [patientInput, setPatientInput] = useState<PatientInputState>({
    sintomiSelezionati: [],
    altriSintomi: ''
  });
  const [doctorInput, setDoctorInput] = useState<DoctorInputState>({
    sintomiSelezionati: [],
    altriSintomi: '',
    storiaClinica: '',
    eta: '',
    sesso: '',
    parametriVitali: '',
  });
  const [wellnessInput, setWellnessInput] = useState<WellnessInputState>({
    eta: '',
    sesso: '',
    altezza: '',
    peso: '',
    livelloAttivita: '',
    obiettivo: '',
    stileAlimentare: '',
    dietaScelta: '',
    condizioniMediche: [],
    allergieEPreferenze: ''
  });
  const [viewMode, setViewMode] = useState<ViewMode>(ViewMode.Patient);
  const [isLoading, setIsLoading] = useState<boolean>(true); // Start true for initial load
  const [error, setError] = useState<string | null>(null);
  const [showDietLibrary, setShowDietLibrary] = useState(false);

  // Results State
  const [patientResult, setPatientResult] = useState<PatientAnalysis | null>(null);
  const [doctorResult, setDoctorResult] = useState<DoctorAnalysis | null>(null);
  const [wellnessResult, setWellnessResult] = useState<WellnessAnalysis | null>(null);

  // User Authentication State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<Record<string, User>>({});
  const [usersData, setUsersData] = useState<Record<string, UserData>>({});
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [welcomeMessage, setWelcomeMessage] = useState<string | null>(null);


  // Load all users and their data from DB on initial render
  useEffect(() => {
    const loadInitialData = async () => {
        setIsLoading(true);
        try {
            const loadedUsers = await db.getAllUsers();
            const loadedUsersData = await db.getAllUsersData();

            let needsSave = false;

            // Ensure all users have a tier
            for (const username in loadedUsers) {
                if (!loadedUsers[username].tier) {
                    loadedUsers[username].tier = 'free';
                    needsSave = true;
                }
            }

            // Ensure admin user exists and has pro tier
            if (!loadedUsers['admin']) {
                const adminPassHashed = await auth.hashPassword('1234');
                loadedUsers['admin'] = { username: 'admin', password_hashed: adminPassHashed, tier: 'pro' };
                needsSave = true;
            }
            
            setUsers(loadedUsers);
            setUsersData(loadedUsersData);

            if (needsSave) {
                // Use the database service to persist changes, fixing architectural bug
                await db.saveAllUsers(loadedUsers);
            }

        } catch (e) {
            console.error("Failed to load user data from database service", e);
            setError("Impossibile caricare i dati dell'applicazione.");
        } finally {
            setIsLoading(false);
        }
    };
    loadInitialData();
  }, []);

  // Effect for welcome message
  useEffect(() => {
    if (welcomeMessage) {
        const timer = setTimeout(() => {
            setWelcomeMessage(null);
        }, 3000);
        return () => clearTimeout(timer);
    }
  }, [welcomeMessage]);

  // Reset results and errors when view mode changes
  useEffect(() => {
    setPatientResult(null);
    setDoctorResult(null);
    setWellnessResult(null);
    setError(null);
    setShowDietLibrary(false); // also reset diet library view
  }, [viewMode]);

  const constructPatientPrompt = (): string => {
    const sintomiSelezionati = patientInput.sintomiSelezionati.length > 0 
        ? patientInput.sintomiSelezionati.join(', ') 
        : 'Nessuno spuntato';
    const altriSintomi = patientInput.altriSintomi.trim() || 'Nessun altro dettaglio fornito.';
    return `Sintomi selezionati dalla lista: ${sintomiSelezionati}.\nAltri sintomi o dettagli aggiuntivi: ${altriSintomi}`;
  };

  const constructDoctorPrompt = (): string => {
    const sintomiSelezionati = doctorInput.sintomiSelezionati.length > 0 
        ? doctorInput.sintomiSelezionati.join(', ') 
        : 'Nessuno spuntato';

    const parts = [];
    parts.push(`Analisi clinica per un paziente con le seguenti caratteristiche:`);
    
    const patientData = [];
    if (doctorInput.eta) patientData.push(`Età: ${doctorInput.eta}`);
    if (doctorInput.sesso) patientData.push(`Sesso: ${doctorInput.sesso}`);
    if (patientData.length > 0) parts.push(`- Dati Paziente: ${patientData.join(', ')}`);
    
    parts.push(`- Sintomi Selezionati: ${sintomiSelezionati}`);
    if (doctorInput.altriSintomi.trim()) parts.push(`- Dettagli aggiuntivi sui sintomi: ${doctorInput.altriSintomi}`);
    if (doctorInput.storiaClinica.trim()) parts.push(`- Storia Clinica Dettagliata: ${doctorInput.storiaClinica}`);
    if (doctorInput.parametriVitali.trim()) parts.push(`- Parametri Vitali/Esami: ${doctorInput.parametriVitali}`);
    
    return parts.join('\n');
  };
  
  const handleAddProgressEntry = async (newEntryData: { weight: number; notes?: string }) => {
    if (!currentUser) return;
    
    const newEntry: ProgressEntry = {
      id: new Date().toISOString(),
      date: new Date().toLocaleDateString('it-IT', { year: 'numeric', month: 'long', day: 'numeric' }),
      ...newEntryData,
    };
    
    const currentUserData = (await db.getUserData(currentUser.username)) || { progressEntries: [] };
    const updatedEntries = [newEntry, ...currentUserData.progressEntries].sort((a, b) => new Date(b.id).getTime() - new Date(a.id).getTime());

    const newUserData = { ...currentUserData, progressEntries: updatedEntries };
    await db.saveUserData(currentUser.username, newUserData);
    
    // Refresh local state
    setUsersData(await db.getAllUsersData());
  };

  const handleSubmit = useCallback(async (event: React.FormEvent) => {
    event.preventDefault();
    
    if (viewMode === ViewMode.Patient && patientInput.sintomiSelezionati.length === 0 && !patientInput.altriSintomi.trim()) {
      setError('Per favore, seleziona almeno un sintomo o descrivine uno.');
      return;
    }
    if (viewMode === ViewMode.Doctor && doctorInput.sintomiSelezionati.length === 0 && !doctorInput.altriSintomi.trim()) {
      setError('Per favore, seleziona almeno un sintomo o fornisci dei dettagli.');
      return;
    }
    if (viewMode === ViewMode.Wellness && !wellnessInput.obiettivo) {
        setError('Per favore, seleziona il tuo obiettivo principale.');
        return;
    }

    setIsLoading(true);
    setError(null);
    setPatientResult(null);
    setDoctorResult(null);
    setWellnessResult(null);

    try {
      if (viewMode === ViewMode.Patient) {
        const prompt = constructPatientPrompt();
        const result = await getPatientAnalysis(prompt);
        setPatientResult(result);
      } else if (viewMode === ViewMode.Doctor) {
        const prompt = constructDoctorPrompt();
        const result = await getDoctorAnalysis(prompt);
        setDoctorResult(result);
      } else if (viewMode === ViewMode.Wellness) {
        const result = await getWellnessAnalysis(wellnessInput, currentUser?.tier || 'free');
        setWellnessResult(result);
      }
    } catch (err: any) {
      setError(err.message || 'Si è verificato un errore sconosciuto.');
    } finally {
      setIsLoading(false);
    }
  }, [patientInput, viewMode, doctorInput, wellnessInput, currentUser]);

  const handleRegister = async (username: string, pass: string): Promise<boolean> => {
    if ((await db.getUser(username))) {
      setError('Questo nome utente esiste già. Prova a fare il login.');
      return false;
    }
    if (username.toLowerCase() === 'admin') {
      setError('Il nome utente "admin" è riservato.');
      return false;
    }

    const password_hashed = await auth.hashPassword(pass);
    const newUser: User = { username, password_hashed, tier: 'free' };
    await db.saveUser(newUser);

    const newUserData: UserData = { progressEntries: [] };
    await db.saveUserData(username, newUserData);
    
    // Refresh local state and log in
    setUsers(await db.getAllUsers());
    setUsersData(await db.getAllUsersData());
    setCurrentUser(newUser);
    setError(null);
    setWelcomeMessage(`Benvenuto in DoctorYou, ${newUser.username}!`);
    return true;
  };

  const handleLogin = async (username: string, pass: string): Promise<boolean> => {
    const user = await db.getUser(username);
    if (user && (await auth.comparePasswords(pass, user.password_hashed))) {
        if (username === 'admin') {
            setIsAdminLoggedIn(true);
            setViewMode(ViewMode.Admin);
        } else {
            setCurrentUser(user);
            setViewMode(ViewMode.Patient); // Reset to default view on login
            setWelcomeMessage(`Bentornato, ${user.username}!`);
        }
        setError(null);
        return true;
    } else {
      setError('Nome utente o password non validi.');
      return false;
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setIsAdminLoggedIn(false);
    setViewMode(ViewMode.Patient);
  };
  
  const handleAdminClick = (e: React.MouseEvent) => {
      e.preventDefault();
      handleLogout();
      setViewMode(ViewMode.Admin);
  };

  const updateUserTier = async (username: string) => {
    const userToUpdate = await db.getUser(username);
    if (userToUpdate && userToUpdate.tier === 'free') {
      const updatedUser: User = { ...userToUpdate, tier: 'pro' };
      await db.saveUser(updatedUser);
      // Refresh local state
      setUsers(await db.getAllUsers());
      alert(`L'utente ${username} è stato aggiornato a PRO.`);
    }
  };

  const renderWelcomeMessage = () => {
    let icon, title, text;

    switch(viewMode) {
      case ViewMode.Patient:
      case ViewMode.Doctor:
        icon = <StethoscopeIcon className="mx-auto h-12 w-12 text-indigo-500 mb-4" />;
        title = "Analisi Sintomi";
        text = viewMode === ViewMode.Patient 
            ? "Seleziona i tuoi sintomi per ricevere un'analisi preliminare." 
            : "Inserisci i dati del paziente per una diagnosi differenziale dettagliata.";
        break;
      case ViewMode.Wellness:
        icon = <HeartPulseIcon className="mx-auto h-12 w-12 text-teal-500 mb-4" />;
        title = "Piano Benessere";
        text = "Compila i tuoi dati e lascia che l'IA ti consigli la dieta migliore, oppure scegline una tu.";
        break;
      default:
        return null; 
    }

    return (
      <div className="text-center p-8 bg-white rounded-xl shadow-md border border-gray-200">
          {icon}
          <h2 className="text-2xl font-bold text-gray-800">{title}</h2>
          <p className="mt-2 text-gray-600">{text}</p>
      </div>
    );
  };

  const renderForm = () => {
      switch(viewMode) {
        case ViewMode.Patient:
            return (
              <>
                <label className="block text-lg font-semibold text-gray-700 mb-4">
                  Seleziona i sintomi che stai riscontrando
                </label>
                <PatientInputForm input={patientInput} setInput={setPatientInput} />
              </>
            );
        case ViewMode.Doctor:
            return (
              <>
                <label className="block text-lg font-semibold text-gray-700 mb-4">
                    Inserisci Dati Clinici del Paziente
                </label>
                <DoctorInputForm input={doctorInput} setInput={setDoctorInput} />
              </>
            );
        case ViewMode.Wellness:
            return (
                <>
                  <label className="block text-lg font-semibold text-gray-700 mb-4">
                      Crea il Tuo Piano Benessere Personalizzato
                  </label>
                  <WellnessInputForm
                    input={wellnessInput}
                    setInput={setWellnessInput}
                    onShowDietLibrary={() => setShowDietLibrary(true)}
                  />
                </>
              );
        default:
            return null;
      }
  };

  const getButtonText = () => {
    if(isLoading) {
        return 'Analisi in corso...'
    }
    switch(viewMode) {
        case ViewMode.Wellness:
            return 'Genera Piano Benessere';
        case ViewMode.Patient:
        case ViewMode.Doctor:
        default:
            return 'Analizza Sintomi';
    }
  };

  const renderMainContent = () => {
    if (isLoading && !currentUser && !isAdminLoggedIn) {
        return <LoadingSpinner />;
    }
    if (viewMode === ViewMode.Admin && !isAdminLoggedIn) {
        return <AdminLogin onLogin={handleLogin} onCancel={() => setViewMode(ViewMode.Patient)} />
    }
    if (isAdminLoggedIn) {
        return <main><AdminPanel users={users} onUpdateUserTier={updateUserTier} onLogout={handleLogout} /></main>;
    }
    if (viewMode === ViewMode.Pricing) {
        return <main><PricingPage onBack={() => setViewMode(ViewMode.Patient)} /></main>;
    }
    
    const progressEntries = (currentUser && usersData[currentUser.username]?.progressEntries) || [];
    const showMainForm = ![ViewMode.Progress, ViewMode.Admin, ViewMode.Pricing].includes(viewMode);
    
    return (
      <>
        <div className="flex justify-center">
          <ViewToggle viewMode={viewMode} setViewMode={setViewMode} />
        </div>

        {viewMode === ViewMode.Wellness && showDietLibrary ? (
            <main className="mt-8">
                <DietLibrary onExit={() => setShowDietLibrary(false)} />
            </main>
        ) : (
            <>
                {showMainForm && (
                <div className="bg-white p-6 md:p-8 rounded-xl shadow-lg border border-gray-200">
                    <form onSubmit={handleSubmit}>
                    {renderForm()}
                    <div className="mt-6 flex justify-end">
                        <button
                        type="submit"
                        disabled={isLoading}
                        className="px-8 py-3 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition-all duration-300"
                        >
                        {getButtonText()}
                        </button>
                    </div>
                    </form>
                </div>
                )}

                <main className="mt-8">
                {isLoading ? (
                    <LoadingSpinner />
                ) : error ? (
                    <div className="bg-red-100 border-l-4 border-red-500 text-red-800 p-4 rounded-md" role="alert"><p className="font-bold">Errore</p><p>{error}</p></div>
                ) : (
                    <>
                    {viewMode === ViewMode.Progress && <ProgressTracker entries={progressEntries} onAddEntry={handleAddProgressEntry} />}
                    {showMainForm && !patientResult && !doctorResult && !wellnessResult && renderWelcomeMessage()}
                    {patientResult && viewMode === ViewMode.Patient && <PatientResults data={patientResult} />}
                    {doctorResult && viewMode === ViewMode.Doctor && <DoctorResults data={doctorResult} />}
                    {wellnessResult && viewMode === ViewMode.Wellness && <WellnessResults userTier={currentUser?.tier || 'free'} data={wellnessResult} onUpgrade={() => setViewMode(ViewMode.Pricing)} />}
                    </>
                )}
                </main>
            </>
        )}
      </>
    );
  };
  
  if (!currentUser && !isAdminLoggedIn) {
    if (isLoading) return <div className="min-h-screen flex items-center justify-center"><LoadingSpinner/></div>
    
    return (
      <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
        <header className="text-center mb-8">
            <h1 className="text-5xl font-bold text-gray-900 tracking-tight">DoctorYou</h1>
            <p className="mt-3 text-lg text-gray-600">Il tuo assistente personale per la salute, basato su IA.</p>
        </header>
        <UserAuth onLogin={handleLogin} onRegister={handleRegister} error={error} setError={setError} />
        <footer className="text-center mt-12 text-sm text-gray-500">
          <p>Sviluppato con React e Gemini API. Questo strumento è solo a scopo informativo.</p>
          <p className="mt-2">
              <a href="#" onClick={handleAdminClick} className="text-indigo-600 hover:underline">
                  Sei un amministratore?
              </a>
          </p>
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center p-4 sm:p-6 lg:p-8 relative">
       {welcomeMessage && (
            <div className="fixed top-5 right-5 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in-out">
                <p className="font-semibold">{welcomeMessage}</p>
            </div>
        )}
      <div className="w-full max-w-4xl mx-auto space-y-8">
        <header className="w-full">
            <div className="flex justify-between items-center mb-6 gap-4 flex-wrap">
                 <div className="flex items-center gap-3 bg-white px-4 py-2 rounded-full shadow-sm border border-gray-200">
                    {isAdminLoggedIn ? (
                        <>
                           <UserCircle2Icon className="h-6 w-6 text-indigo-600" />
                           <span className="font-semibold text-gray-800 text-lg">Admin</span>
                        </>
                    ) : (
                        <>
                            <UserCircle2Icon className="h-6 w-6 text-gray-500" />
                            <span className="font-semibold text-gray-800 text-lg">{currentUser?.username}</span>
                             <span className={`text-xs font-bold uppercase px-2 py-1 rounded-full ${currentUser?.tier === 'pro' ? 'bg-amber-100 text-amber-800' : 'bg-gray-200 text-gray-700'}`}>
                                {currentUser?.tier}
                            </span>
                        </>
                    )}
                </div>
                <div className="flex items-center gap-4">
                    {currentUser?.tier === 'free' && (
                        <button 
                            onClick={() => setViewMode(ViewMode.Pricing)}
                            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-teal-500 hover:bg-teal-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-colors"
                        >
                            <CrownIcon className="h-5 w-5 mr-2" />
                            Passa a PRO
                        </button>
                    )}
                    <button
                      onClick={handleLogout}
                      className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
                    >
                        <LogOutIcon className="h-5 w-5 mr-2" />
                        Logout
                    </button>
                </div>
            </div>
            <div className="text-center">
                <h1 className="text-5xl font-bold text-gray-900 tracking-tight">DoctorYou</h1>
                 <p className="mt-3 text-lg text-gray-600">Il tuo assistente personale per la salute, basato su IA.</p>
            </div>
        </header>
        
        {renderMainContent()}
        
      </div>
      <footer className="text-center mt-12 text-sm text-gray-500">
        <p>Sviluppato con React e Gemini API. Questo strumento è solo a scopo informativo.</p>
      </footer>
    </div>
  );
};

export default App;