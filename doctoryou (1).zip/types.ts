export enum ViewMode {
  Patient = 'Patient',
  Doctor = 'Doctor',
  Wellness = 'Wellness',
  Progress = 'Progress',
  Admin = 'Admin',
  Pricing = 'Pricing',
}

// For Patient Input Form
export interface PatientInputState {
  sintomiSelezionati: string[];
  altriSintomi: string;
}

// For Doctor Input Form
export interface DoctorInputState {
  sintomiSelezionati: string[];
  altriSintomi: string;
  storiaClinica: string;
  eta: string;
  sesso: string;
  parametriVitali: string;
}

// For Wellness Input Form
export interface WellnessInputState {
  eta: string;
  sesso: string;
  altezza: string;
  peso: string;
  livelloAttivita: 'sedentario' | 'leggero' | 'attivo' | 'molto_attivo' | '';
  obiettivo: 'dimagrire' | 'ingrassare' | 'aumentare_massa_muscolare' | 'migliorare_salute' | 'gestire_patologie' | '';
  stileAlimentare: 'onnivoro' | 'vegetariano' | 'vegano' | '';
  dietaScelta: string;
  condizioniMediche: string[];
  allergieEPreferenze: string;
}

// For Progress Tracking
export interface ProgressEntry {
  id: string;
  date: string;
  weight: number;
  notes?: string;
}

// For Patient View
export interface PossibleCondition {
  name: string;
  description: string;
  treatments: string[];
  whenToSeeDoctor: string[];
}

export interface PatientAnalysis {
  disclaimer: string;
  possibleConditions: PossibleCondition[];
}


// For Doctor View
export interface DifferentialDiagnosis {
  condition: string;
  icd10Code: string;
  medications: string[];
  clinicalInsights: string;
}

export interface DoctorAnalysis {
  disclaimer: string;
  differentialDiagnosis: DifferentialDiagnosis[];
  suggestedReferral: string;
}

// For Wellness View
export interface MealSuggestion {
  pasto: string;
  descrizione: string;
  calorieStimate: number;
}

export interface ActivitySuggestion {
  tipo: string;
  descrizione: string;
  frequenza: string;
}

export interface SupplementSuggestion {
    nome: string;
    scopo: string;
    dosaggioConsigliato: string;
}

export interface DailyPlan {
    giorno: number;
    pasti: MealSuggestion[];
}

export interface ShoppingListItem {
    ingrediente: string;
    quantita: string;
}

export interface WellnessAnalysis {
  disclaimer: string;
  dietaConsigliata: {
    nome: string;
    motivazione: string;
  };
  fabbisognoCaloricoGiornaliero: {
    valore: number;
    spiegazione: string;
  };
  pianoAlimentare: DailyPlan[];
  suggerimentiAttivitaFisica: ActivitySuggestion[];
  suggerimentiIntegratori: SupplementSuggestion[];
  listaSpesa: ShoppingListItem[];
  costoApprossimativo: {
    valore: number;
    valuta: string;
    spiegazione: string;
  };
}

// For Diet Library
export interface DietMeal {
  pasto: string;
  descrizione: string;
}

export interface DietDetail {
  nome: string;
  descrizione: string;
  principiChiave: string[];
  potenzialiBenefici: string[];
  rischiEConsiderazioni: string[];
  alimentiConsigliati: string[];
  alimentiDaEvitare: string[];
  esempioPianoGiornaliero: DietMeal[];
}

// For User Authentication
export interface User {
  username: string;
  password_hashed: string; 
  tier: 'free' | 'pro';
}

export interface UserData {
  progressEntries: ProgressEntry[];
}